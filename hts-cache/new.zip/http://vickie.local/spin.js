<!DOCTYPE html>
<html lang="en-US">
<head>
					<script>document.documentElement.className = document.documentElement.className + ' yes-js js_active js'</script>
			<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">



<link rel="profile" href="http://gmpg.org/xfn/11" />

	<link rel="shortcut icon" href="http://vickie.local/wp-content/themes/g5plus-auteur/assets/images/favicon.ico" />





<title>Page not found &#8211; Vickie Swan</title>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Vickie Swan &raquo; Feed" href="http://vickie.local/feed/" />
<link rel="alternate" type="application/rss+xml" title="Vickie Swan &raquo; Comments Feed" href="http://vickie.local/comments/feed/" />
<link rel="alternate" type="text/calendar" title="Vickie Swan &raquo; iCal Feed" href="http://vickie.local/events/?ical=1" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/vickie.local\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.5.5"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='gsf_google-fonts-css'  href='https://fonts.googleapis.com/css?family=Libre+Baskerville%3Aregular%2C400i%2C700%7CNunito+Sans%3A300%2Cregular%2C400i%2C600%2C600i%2C700%2C700i%2C800%2C800i%2C900%2C900i&#038;subset=latin&#038;ver=5.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-common-skeleton-style-css'  href='http://vickie.local/wp-content/plugins/the-events-calendar/common/src/resources/css/common-skeleton.min.css?ver=4.12.6' type='text/css' media='all' />
<link rel='stylesheet' id='tribe-tooltip-css'  href='http://vickie.local/wp-content/plugins/the-events-calendar/common/src/resources/css/tooltip.min.css?ver=4.12.6' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='http://vickie.local/wp-includes/css/dist/block-library/style.min.css?ver=5.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-theme-css'  href='http://vickie.local/wp-includes/css/dist/block-library/theme.min.css?ver=5.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='http://vickie.local/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style.css?ver=2.7.3' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='http://vickie.local/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=2.7.3' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-selectBox-css'  href='http://vickie.local/wp-content/plugins/yith-woocommerce-wishlist/assets/css/jquery.selectBox.css?ver=1.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='yith-wcwl-font-awesome-css'  href='http://vickie.local/wp-content/plugins/yith-woocommerce-wishlist/assets/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='yith-wcwl-main-css'  href='http://vickie.local/wp-content/plugins/yith-woocommerce-wishlist/assets/css/style.css?ver=3.0.11' type='text/css' media='all' />
<link rel='stylesheet' id='gsf_admin-bar-css'  href='http://vickie.local/wp-content/plugins/auteur-framework/assets/css/admin-bar.min.css?ver=1.2' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-5pro-css'  href='http://vickie.local/wp-content/plugins/auteur-framework/libs/smart-framework/assets/vendors/font-awesome/css/fontawesome.css?ver=5.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='gsf_xmenu-animate-css'  href='http://vickie.local/wp-content/plugins/auteur-framework/core/xmenu/assets/css/animate.min.css?ver=3.5.1' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://vickie.local/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='ladda-css'  href='http://vickie.local/wp-content/plugins/g5plus-post-like/assets/vendors/ladda/ladda-themeless.min.css?ver=1.0.5' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='http://vickie.local/wp-includes/css/dashicons.min.css?ver=5.5.5' type='text/css' media='all' />
<style id='dashicons-inline-css' type='text/css'>
[data-font="Dashicons"]:before {font-family: 'Dashicons' !important;content: attr(data-icon) !important;speak: none !important;font-weight: normal !important;font-variant: normal !important;text-transform: none !important;line-height: 1 !important;font-style: normal !important;-webkit-font-smoothing: antialiased !important;-moz-osx-font-smoothing: grayscale !important;}
</style>
<link rel='stylesheet' id='post-views-counter-frontend-css'  href='http://vickie.local/wp-content/plugins/post-views-counter/css/frontend.css?ver=1.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://vickie.local/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.8.1' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='woocommerce-layout-css'  href='http://vickie.local/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=4.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='http://vickie.local/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=4.3.4' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='http://vickie.local/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=4.3.4' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='jquery-colorbox-css'  href='http://vickie.local/wp-content/plugins/yith-woocommerce-compare/assets/css/colorbox.css?ver=5.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='woocommerce_prettyPhoto_css-css'  href='//vickie.local/wp-content/plugins/woocommerce/assets/css/prettyPhoto.css?ver=5.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/bootstrap-4.0.0/css/bootstrap.min.css?ver=4.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='custom-bootstrap-css'  href='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/bootstrap-4.0.0/css/custom-bootstrap.min.css?ver=4.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='owl-carousel-css'  href='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/owl.carousel/assets/owl.carousel.min.css?ver=2.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='owl-carousel-theme-default-css'  href='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/owl.carousel/assets/owl.theme.default.min.css?ver=2.2.0' type='text/css' media='all' />
<link rel='stylesheet' id='perfect-scrollbar-css'  href='http://vickie.local/wp-content/plugins/auteur-framework/libs/smart-framework/assets/vendors/perfect-scrollbar/css/perfect-scrollbar.min.css?ver=0.6.11' type='text/css' media='all' />
<link rel='stylesheet' id='magnific-popup-css'  href='http://vickie.local/wp-content/plugins/auteur-framework/libs/smart-framework/assets/vendors/magnific-popup/magnific-popup.min.css?ver=1.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='animate-css-css'  href='http://vickie.local/wp-content/themes/g5plus-auteur/assets/css/animate.min.css?ver=1.0' type='text/css' media='all' />
<link rel='stylesheet' id='slick-css'  href='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/slick/css/slick.min.css?ver=5.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='gsf_main-css'  href='http://vickie.local/wp-content/themes/g5plus-auteur/assets/preset/404.min.css?ver=5.5.5' type='text/css' media='all' />
<style id='gsf_main-inline-css' type='text/css'>
			body {
				background-color: #fff !important
			}			.main-header {
				background-color: rgba(255,255,255,0) !important
			}			.main-header .header-sticky.affix {
				background-color: #ffffff !important
			}			.mobile-header {
				background-color: #fff !important
			}			.mobile-header .header-sticky.affix {
				background-color: #fff !important; background-image: url('#fff'); background-repeat: repeat; background-position: center center; background-size: contain; background-attachment: scroll
			}				.site-loading {
					background-color: #fff !important;
				}				.main-header.header-4 .primary-menu {
					background-color: #fff !important;
				}				#popup-canvas-menu .modal-content {
					background-color: #fff !important;
				}				.main-header.header-4 .header-sticky.affix.primary-menu {
					background-color: #fff !important;
				}				.main-menu .sub-menu {
					background-color: #fff !important;
				}                            .top-drawer-content {
                                                            padding-top: 10px;                            padding-bottom: 10px;
                            }                            @media (min-width: 992px) {
                                .gsf-catalog-full-width .woocommerce-custom-wrap > .container, .gsf-catalog-full-width #gf-filter-content > .container, .gsf-catalog-full-width .clear-filter-wrap > .container {
                                                                padding-left: 100px;                            padding-right: 100px;
                                }
                            }                        @media (max-width: 991px) {
                            #primary-content {
                                                            padding-left: 0px;                            padding-right: 0px;                            padding-top: 0px;                            padding-bottom: 0px;
                            }
                        }
                .embed-responsive-thumbnail:before,    
                .thumbnail-size-thumbnail:before {
                    padding-top: 100%;
                }                .embed-responsive-medium:before,    
                .thumbnail-size-medium:before {
                    padding-top: 100%;
                }                .embed-responsive-large:before,    
                .thumbnail-size-large:before {
                    padding-top: 100%;
                }                .embed-responsive-1536x1536:before,    
                .thumbnail-size-1536x1536:before {
                    padding-top: 100%;
                }                .embed-responsive-2048x2048:before,    
                .thumbnail-size-2048x2048:before {
                    padding-top: 100%;
                }                .embed-responsive-yith-woocompare-image:before,    
                .thumbnail-size-yith-woocompare-image:before {
                    padding-top: 70%;
                }                .embed-responsive-woocommerce_thumbnail:before,    
                .thumbnail-size-woocommerce_thumbnail:before {
                    padding-top: 140%;
                }                .embed-responsive-woocommerce_gallery_thumbnail:before,    
                .thumbnail-size-woocommerce_gallery_thumbnail:before {
                    padding-top: 100%;
                }                .embed-responsive-shop_catalog:before,    
                .thumbnail-size-shop_catalog:before {
                    padding-top: 140%;
                }                .embed-responsive-shop_thumbnail:before,    
                .thumbnail-size-shop_thumbnail:before {
                    padding-top: 100%;
                }.vc_custom_1542014395452{background-color: #f4f3ec !important;}.vc_custom_1545877085097{background-image: url(http://vickieswan.ca/wp-content/uploads/2018/12/footer-background.jpg?id=737) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1544169783179{padding-top: 7px !important;}.vc_custom_1542868671272{background-image: url(http://vickieswan.ca/wp-content/uploads/2018/11/404-background.jpg?id=554) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1542868309203{background-color: #ffffff !important;}.vc_custom_1542869141622{margin-top: 20px !important;margin-right: 20px !important;margin-bottom: 20px !important;margin-left: 20px !important;border-top-width: 1px !important;border-right-width: 1px !important;border-bottom-width: 1px !important;border-left-width: 1px !important;padding-bottom: 48px !important;border-left-color: #e4e2d8 !important;border-left-style: solid !important;border-right-color: #e4e2d8 !important;border-right-style: solid !important;border-top-color: #e4e2d8 !important;border-top-style: solid !important;border-bottom-color: #e4e2d8 !important;border-bottom-style: solid !important;}.vc_custom_1542869069244{margin-top: 32px !important;margin-bottom: 18px !important;}.vc_custom_1542869127445{margin-bottom: 45px !important;}.vc_custom_1542868760088{margin-right: 15px !important;margin-left: 15px !important;}            .product-author-wrap .author-avatar-wrap:after {
              background-image: url('http://vickie.local/wp-content/themes/g5plus-auteur/assets/images/diagonal-stripes.png');
            }

            .single-author-info .single-author-thumbnail .author-thumbnail-inner:before {
              background-image: url('http://vickie.local/wp-content/themes/g5plus-auteur/assets/images/diagonal-stripes-01.png');
            }
</style>
<link rel='stylesheet' id='gsf_skin-skin-light-css'  href='http://vickie.local/wp-content/themes/g5plus-auteur/assets/skin/skin-light.min.css?ver=5.5.5' type='text/css' media='all' />
<link rel='stylesheet' id='js_composer_front-css'  href='http://vickie.local/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=5.6' type='text/css' media='all' />
		<script>
			/* <![CDATA[ */
			var rcewpp = {
				"ajax_url":"http://vickie.local/wp-admin/admin-ajax.php",
				"nonce": "7c5f3e9455",
				"home_url": "http://vickie.local"
			};
			/* ]]\> */
		</script>
		<script type='text/javascript' src='http://vickie.local/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp' id='jquery-core-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.8.1' id='tp-tools-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.8.1' id='revmin-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"http:\/\/vickie.local\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=4.3.4' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=5.6' id='vc_woocommerce-add-to-cart-js-js'></script>
<link rel="https://api.w.org/" href="http://vickie.local/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://vickie.local/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://vickie.local/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.5.5" />
<meta name="generator" content="WooCommerce 4.3.4" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" type="90b277b09cef7490f90e10a2-text/javascript"></script>


<script type="90b277b09cef7490f90e10a2-text/javascript">
   
    
   jQuery(document).ready(function($) {
    $(".scrollSlow").click(function(event){     
        event.preventDefault();
        $('html,body').animate({scrollTop:$(this.hash).offset().top}, 3500);
    });
});
  
   jQuery(document).ready(function($) {
    $(".scrollFast").click(function(event){     
        event.preventDefault();
        $('html,body').animate({scrollTop:$(this.hash).offset().top}, 1500);
    });
});
        
    </script>
<style>
    
    @media screen and (max-width: 600px) {
  .not_mobile {
    visibility: hidden;
    clear: both;
    float: left;
    margin: 10px auto 5px 20px;
    width: 28%;
    display: none;
  }
}
    
    </style><meta name="tec-api-version" content="v1"><meta name="tec-api-origin" content="http://vickie.local"><link rel="https://theeventscalendar.com/" href="http://vickie.local/wp-json/tribe/events/v1/" /><style type="text/css" id="g5plus-custom-css"></style><style type="text/css" id="g5plus-custom-js"></style>	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="http://vickie.local/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.4.8.1 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<script type="text/javascript">function setREVStartSize(e){									
						try{ e.c=jQuery(e.c);var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;
							if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
						}catch(d){console.log("Failure at Presize of Slider:"+d)}						
					};</script>
<style type="text/css" id="gsf-custom-css"></style>		<style type="text/css" id="wp-custom-css">
			
.fa-search 
{
	display:none;
}

.shopping-cart-icon
{
	display:none;
}

.fa-user{
	display:none;
}

.gf-toggle-icon {
	display:none;
}

.add_to_wishlist {
	display:none !important;
}

.product-quick-view {
	display:none !important;
}

.compare {
	display:none !important;
}

.gf-social-networks {
display:none !important;
}

.custom-footer-text-list {
	display:none;
}

.bottom-logo {
	width: 130px;
	display: block;
  margin-left: auto;
  margin-right: auto;
  
}		</style>
		<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>
<body class="error404 wp-embed-responsive theme-g5plus-auteur woocommerce-no-js tribe-no-js unknown wpb-js-composer js-comp-ver-5.6 vc_responsive">
			<!-- Open Wrapper -->
	<div id="gf-wrapper" class="gf-skin skin-light">
		<header data-layout="header-10" data-responsive-breakpoint="991" data-navigation="35" data-sticky-type="scroll_up" class="main-header header-10 header-float navigation-1">
        <div class="header-wrap header-sticky">
    <div class="container">
        <div class="header-inner clearfix d-flex align-items-center">
            <div class="logo-header d-flex align-items-center">
        <a class="main-logo gsf-link" href="http://vickie.local/" title="Vickie Swan-Author">
                    <img data-retina="http://vickieswan.ca/wp-content/uploads/2019/01/logo-black2x.png" src="http://vickieswan.ca/wp-content/uploads/2019/01/logo-black.png" alt="Vickie Swan-Author">
            </a>
        </div>
        </div>
    </div>
</div>


</header>
<header data-sticky-type="scroll_up" class="mobile-header header-1">
		<div class="mobile-header-wrap header-sticky">
	<div class="container">
		<div class="mobile-header-inner clearfix d-flex align-items-center">
			<div class="mobile-header-menu">
	<div data-off-canvas="true" data-off-canvas-target="#mobile-navigation-wrapper" data-off-canvas-position="left"
	     class="gf-toggle-icon"><span></span></div>
</div>
			<div class="mobile-logo-header align-items-center d-flex">
	<a class="gsf-link main-logo" href="http://vickie.local/" title="Vickie Swan-Author">
					<img data-retina="http://vickieswan.ca/wp-content/uploads/2019/01/logo-black2x.png" src="http://vickieswan.ca/wp-content/uploads/2019/01/logo-black.png" alt="Vickie Swan-Author">
			</a>
    </div>


			<ul class="header-customize header-customize-mobile gf-inline d-flex align-items-center">
			            			<li class="customize-search">
				    <a class="search-popup-link" href="#search-popup"><i class="fal fa-search"></i></a>
			</li>
            			</ul>
		</div>
	</div>
</div>
	</header>
		<!-- Open Wrapper Content -->
		<div id="wrapper-content" class="clearfix ">
			<!-- Primary Content Wrapper -->
<div id="primary-content" class="gsf-primary-content-full-width">
	<!-- Primary Content Container -->
	<div class="container clearfix">
				<!-- Primary Content Row -->
		<div class="row clearfix">
			<!-- Primary Content Inner -->
			<div class="col-lg-12">


    		<div class="vc_row wpb_row vc_row-fluid vc_custom_1542868671272 vc_row-has-fill vc_row-o-full-height vc_row-o-columns-middle vc_row-o-content-middle vc_row-flex">
                                        <div class="gf-row-inner gf-container container">
                        <div class="bg-clip-content wpb_column vc_column_container vc_col-sm-12 vc_col-lg-offset-2 vc_col-lg-8 vc_col-md-offset-1 vc_col-md-10 vc_col-has-fill"><div class="vc_column-inner vc_custom_1542868309203"><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid text-center vc_custom_1542869141622 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner"><div class="wpb_wrapper">    <div class="gf-heading gf-heading-style-3 vc_custom_1542869069244">
        <div class="gf-heading-inner gf-heading-60f8df4f7ec52 text-center justify-content-center">
                                                        <h4 class="heading-title">404</h4>
                    </div>
    </div>
    <div class="gf-heading gf-heading-style-4 vc_custom_1542869127445">
        <div class="gf-heading-inner gf-heading-60f8df4f7f4d0 text-center justify-content-center">
                            <span class="heading-sub-title disable-color">You could either go back or go to homepage</span>
                                                        <h4 class="heading-title">Woops, looks like this page does not exist</h4>
                    </div>
    </div>
<div class="btn-container dib vc_custom_1542868760088 btn-inline">
            <a class="btn btn-accent btn-classic btn-md btn-square btn-icon btn-icon-left" href="http://vickieswan.flywheelsites.com/" title="Homepage"><i class="fal fa-home"></i>HOMEPAGE</a>
    </div>

<div class="btn-container dib btn-inline">
            <a class="btn btn-gray btn-outline btn-md btn-square btn-icon btn-icon-left" href="http://vickieswan.flywheelsites.com/" title="Homepage"><i class="fal fa-reply-all"></i>GO BACK</a>
    </div>

</div></div></div></div></div></div></div>							</div>
			
		</div>

			</div> <!-- End Primary Content Inner -->
					</div> <!-- End Primary Content Row -->
	</div> <!-- End Primary Content Container -->
</div> <!-- End Primary Content Wrapper -->
</div><!-- Close Wrapper Content -->
</div><!-- Close Wrapper -->
<a class="back-to-top" href="javascript:;">
	<i class="fa fa-angle-up"></i>
</a>
<div data-search-ajax="true" data-search-ajax-action="search_popup"
     data-search-ajax-nonce="af853b65fb" id="search-popup"
     class="search-popup-wrap mfp-hide mfp-with-anim">
    	<form action="http://vickie.local/" method="get" class="search-popup-form clearfix">
		<input data-search-ajax-control="input" name="s" class="search-popup-field" type="search"
		       placeholder="Type at least 3 characters to search"
		       autocomplete="off">
        		<button type="submit" class="search-popup-button" ><i data-search-ajax-control="icon" class="fal fa-search"></i></button>
	</form>
	<div data-search-ajax-control="result" class="search-popup-result"></div>
</div>
<script>
var buttonsToChange = document.getElementsByClassName('product_out_of_stock');
console.dir(buttonsToChange);
buttonsToChange[1].href="https://www.amazon.com/Split-Second-Decision-Vickie-Swan/dp/1946854166/ref=sr_1_1?ie=UTF8&qid=1525457576&sr=8-1&keywords=9781946854162";
buttonsToChange[3].href="https://www.amazon.com/Split-Second-Decision-II-Apprehended/dp/1946854182/ref=sr_1_1?s=books&ie=UTF8&qid=1525457837&sr=1-1&keywords=9781946854186";
buttonsToChange[1].target="_blank";
buttonsToChange[3].target="_blank";

</script>		<script>
		( function ( body ) {
			'use strict';
			body.className = body.className.replace( /\btribe-no-js\b/, 'tribe-js' );
		} )( document.body );
		</script>
		<script>jQuery("style#g5plus-custom-css").append("   ");</script><script>jQuery("style#g5plus-custom-js").append("   ");</script><script> /* <![CDATA[ */var tribe_l10n_datatables = {"aria":{"sort_ascending":": activate to sort column ascending","sort_descending":": activate to sort column descending"},"length_menu":"Show _MENU_ entries","empty_table":"No data available in table","info":"Showing _START_ to _END_ of _TOTAL_ entries","info_empty":"Showing 0 to 0 of 0 entries","info_filtered":"(filtered from _MAX_ total entries)","zero_records":"No matching records found","search":"Search:","all_selected_text":"All items on this page were selected. ","select_all_link":"Select all pages","clear_selection":"Clear Selection.","pagination":{"all":"All","next":"Next","previous":"Previous"},"select":{"rows":{"0":"","_":": Selected %d rows","1":": Selected 1 row"}},"datepicker":{"dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesMin":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Prev","currentText":"Today","closeText":"Done","today":"Today","clear":"Clear"}};/* ]]> */ </script>	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<div id="mobile-navigation-wrapper" class="mobile-navigation-wrapper canvas-sidebar-wrapper">
	<div class="canvas-sidebar-inner">
		<form role="search" method="get" class="search-form" action="http://vickie.local/">
	<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
	<button type="submit" class="search-submit"><i class="fal fa-search"></i></button>
</form>
			</div>
</div>
<div class="canvas-overlay"></div>

<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="pswp__bg"></div>
	<div class="pswp__scroll-wrap">
		<div class="pswp__container">
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
		</div>
		<div class="pswp__ui pswp__ui--hidden">
			<div class="pswp__top-bar">
				<div class="pswp__counter"></div>
				<button class="pswp__button pswp__button--close" aria-label="Close (Esc)"></button>
				<button class="pswp__button pswp__button--share" aria-label="Share"></button>
				<button class="pswp__button pswp__button--fs" aria-label="Toggle fullscreen"></button>
				<button class="pswp__button pswp__button--zoom" aria-label="Zoom in/out"></button>
				<div class="pswp__preloader">
					<div class="pswp__preloader__icn">
						<div class="pswp__preloader__cut">
							<div class="pswp__preloader__donut"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
				<div class="pswp__share-tooltip"></div>
			</div>
			<button class="pswp__button pswp__button--arrow--left" aria-label="Previous (arrow left)"></button>
			<button class="pswp__button pswp__button--arrow--right" aria-label="Next (arrow right)"></button>
			<div class="pswp__caption">
				<div class="pswp__caption__center"></div>
			</div>
		</div>
	</div>
</div>
<script type="text/template" id="tmpl-variation-template">
	<div class="woocommerce-variation-description">{{{ data.variation.variation_description }}}</div>
	<div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div>
	<div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div>
</script>
<script type="text/template" id="tmpl-unavailable-variation-template">
	<p>Sorry, this product is unavailable. Please choose a different combination.</p>
</script>
<link rel='stylesheet' id='gsf_g5-heading-css'  href='http://vickie.local/wp-content/plugins/auteur-framework/shortcodes/heading/assets/css/heading.min.css?ver=1.2' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-css'  href='http://vickie.local/wp-content/plugins/woocommerce/assets/css/photoswipe/photoswipe.min.css?ver=4.3.4' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-default-skin-css'  href='http://vickie.local/wp-content/plugins/woocommerce/assets/css/photoswipe/default-skin/default-skin.min.css?ver=4.3.4' type='text/css' media='all' />
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.selectBox.min.js?ver=1.2.0' id='jquery-selectBox-js'></script>
<script type='text/javascript' id='jquery-yith-wcwl-js-extra'>
/* <![CDATA[ */
var yith_wcwl_l10n = {"ajax_url":"\/wp-admin\/admin-ajax.php","redirect_to_cart":"no","multi_wishlist":"","hide_add_button":"1","enable_ajax_loading":"","ajax_loader_url":"http:\/\/vickie.local\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader-alt.svg","remove_from_wishlist_after_add_to_cart":"1","is_wishlist_responsive":"1","labels":{"cookie_disabled":"We are sorry, but this feature is available only if cookies on your browser are enabled.","added_to_cart_message":"<div class=\"woocommerce-notices-wrapper\"><div class=\"woocommerce-message\" role=\"alert\">Product added to cart successfully<\/div><\/div>"},"actions":{"add_to_wishlist_action":"add_to_wishlist","remove_from_wishlist_action":"remove_from_wishlist","reload_wishlist_and_adding_elem_action":"reload_wishlist_and_adding_elem","load_mobile_action":"load_mobile","delete_item_action":"delete_item","save_title_action":"save_title","save_privacy_action":"save_privacy","load_fragments":"load_fragments"}};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.yith-wcwl.js?ver=3.0.11' id='jquery-yith-wcwl-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/auteur-framework/core/xmenu/assets/js/xmenu.min.js?ver=1.2' id='gsf_xmenu-js'></script>
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/vickie.local\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.2.1' id='contact-form-7-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/g5plus-post-like/assets/vendors/ladda/spin.min.js?ver=1.0.5' id='ladda-spin-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/g5plus-post-like/assets/vendors/ladda/ladda.min.js?ver=1.0.5' id='ladda-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/g5plus-post-like/assets/vendors/ladda/ladda.jquery.min.js?ver=1.0.5' id='ladda-jquery-js'></script>
<script type='text/javascript' id='gpl_main-js-extra'>
/* <![CDATA[ */
var gpl_variable = {"ajax_url":"http:\/\/vickie.local\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/g5plus-post-like/assets/js/main.min.js?ver=1.0' id='gpl_main-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=4.3.4' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_e2b23e50fb4f274b925a3dca7355c111","fragment_name":"wc_fragments_e2b23e50fb4f274b925a3dca7355c111","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=4.3.4' id='wc-cart-fragments-js'></script>
<script type='text/javascript' id='yith-woocompare-main-js-extra'>
/* <![CDATA[ */
var yith_woocompare = {"ajaxurl":"\/?wc-ajax=%%endpoint%%","actionadd":"yith-woocompare-add-product","actionremove":"yith-woocompare-remove-product","actionview":"yith-woocompare-view-table","actionreload":"yith-woocompare-reload-product","added_label":"Added","table_title":"Product Comparison","auto_open":"yes","loader":"http:\/\/vickie.local\/wp-content\/plugins\/yith-woocommerce-compare\/assets\/images\/loader.gif","button_text":"Compare","cookie_name":"yith_woocompare_list","close_label":"Close"};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/yith-woocommerce-compare/assets/js/woocompare.min.js?ver=2.3.22' id='yith-woocompare-main-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/yith-woocommerce-compare/assets/js/jquery.colorbox-min.js?ver=1.4.21' id='jquery-colorbox-js'></script>
<script type='text/javascript' src='//vickie.local/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min.js?ver=3.1.6' id='prettyPhoto-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/modernizr/modernizr.js?ver=3.5.0' id='modernizr-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-includes/js/imagesloaded.min.js?ver=4.1.4' id='imagesloaded-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/jquery.easing/jquery.easing.1.3.js?ver=1.3' id='jquery-easing-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/jquery.countdown/jquery.countdown.min.js?ver=2.2.0' id='jquery-countdown-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/popper/popper.min.js?ver=1.0.0' id='popper-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/bootstrap-4.0.0/js/bootstrap.affix.min.js?ver=1.0.0' id='bootstrap-affix-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/bootstrap-4.0.0/js/bootstrap.min.js?ver=4.0.0' id='bootstrap-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/owl.carousel/owl.carousel.min.js?ver=2.2.0' id='owl-carousel-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/isotope/isotope.pkgd.min.js?ver=3.0.5' id='isotope-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/auteur-framework/libs/smart-framework/assets/vendors/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js?ver=0.6.11' id='perfect-scrollbar-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/auteur-framework/libs/smart-framework/assets/vendors/magnific-popup/jquery.magnific-popup.min.js?ver=1.1.0' id='magnific-popup-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/jquery.cookie/jquery.cookie.min.js?ver=1.4.1' id='jquery-cookie-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/waypoints/jquery.waypoints.min.js?ver=4.0.1' id='waypoints-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/auteur-framework/libs/smart-framework/assets/vendors/hc-sticky/jquery.hc-sticky.min.js?ver=1.2.43' id='hc-sticky-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/pretty-tabs/jquery.pretty-tabs.min.js?ver=1.0' id='pretty-tabs-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/vendors/slick/js/slick.min.js?ver=5.5.5' id='slick-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/js/core.min.js?ver=1.0' id='gsf_core-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/js/woocommerce.min.js?ver=1.0' id='gsf_woocommerce-js'></script>
<script type='text/javascript' id='gsf_woocommerce-swatches-js-extra'>
/* <![CDATA[ */
var woocommerce_swatches_var = {"price_selector":".price","localization":{"add_to_cart_text":"Add to cart","read_more_text":"Read more","select_options_text":"Select options"}};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/js/woocommerce-swatches.min.js?ver=1.0' id='gsf_woocommerce-swatches-js'></script>
<script type='text/javascript' id='gsf_main-js-extra'>
/* <![CDATA[ */
var g5plus_variable = {"ajax_url":"http:\/\/vickie.local\/wp-admin\/admin-ajax.php","theme_url":"http:\/\/vickie.local\/wp-content\/themes\/g5plus-auteur\/","site_url":"http:\/\/vickie.local","pretty_tabs_more_text":"More <span class=\"caret\"><\/span>"};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-content/themes/g5plus-auteur/assets/js/main.min.js?ver=1.0' id='gsf_main-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-includes/js/wp-embed.min.js?ver=5.5.5' id='wp-embed-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=5.6' id='wpb_composer_front_js-js'></script>
<script src='http://vickie.local/wp-content/plugins/the-events-calendar/common/src/resources/js/underscore-before.js'></script>
<script type='text/javascript' src='http://vickie.local/wp-includes/js/underscore.min.js?ver=1.8.3' id='underscore-js'></script>
<script src='http://vickie.local/wp-content/plugins/the-events-calendar/common/src/resources/js/underscore-after.js'></script>
<script type='text/javascript' id='wp-util-js-extra'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-includes/js/wp-util.min.js?ver=5.5.5' id='wp-util-js'></script>
<script type='text/javascript' id='wc-add-to-cart-variation-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_variation_params = {"wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_make_a_selection_text":"Please select some product options before adding this product to your cart.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination."};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js?ver=4.3.4' id='wc-add-to-cart-variation-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/woocommerce/assets/js/zoom/jquery.zoom.min.js?ver=1.7.21' id='zoom-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe.min.js?ver=4.1.1' id='photoswipe-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe-ui-default.min.js?ver=4.1.1' id='photoswipe-ui-default-js'></script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/js_composer/assets/lib/bower/flexslider/jquery.flexslider-min.js?ver=5.6' id='flexslider-js'></script>
<script type='text/javascript' id='wc-single-product-js-extra'>
/* <![CDATA[ */
var wc_single_product_params = {"i18n_required_rating_text":"Please select a rating","review_rating_required":"yes","flexslider":{"rtl":false,"animation":"slide","smoothHeight":true,"directionNav":false,"controlNav":"thumbnails","slideshow":false,"animationSpeed":500,"animationLoop":false,"allowOneSlide":false},"zoom_enabled":"1","zoom_options":[],"photoswipe_enabled":"1","photoswipe_options":{"shareEl":false,"closeOnScroll":false,"history":false,"hideAnimationDuration":0,"showAnimationDuration":0},"flexslider_enabled":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://vickie.local/wp-content/plugins/woocommerce/assets/js/frontend/single-product.min.js?ver=4.3.4' id='wc-single-product-js'></script>
<script>jQuery("style#gsf-custom-css").append("           .gf-heading-60f8df4f7ec52 .heading-title {            color: #333333 !important;            font-size: 100px !important;            line-height: 1.2em !important;        }        @media (min-width: 992px) and (max-width: 1199px) {            .gf-heading-60f8df4f7ec52 .heading-title {                font-size: 80px !important;            }        }        @media (min-width: 768px) and (max-width: 991px) {            .gf-heading-60f8df4f7ec52 .heading-title {                font-size: 72px !important;            }        }        @media (min-width: 576px) and (max-width: 767px) {            .gf-heading-60f8df4f7ec52 .heading-title {                font-size: 60px !important;            }        }        @media (max-width: 575px) {            .gf-heading-60f8df4f7ec52 .heading-title {                font-size: 56px !important;            }        }    .gf-heading-60f8df4f7ec52 .heading-title {        font-family: Libre Baskerville !important;        font-weight: 700 !important;        font-style: normal !important;}            .gf-heading-60f8df4f7ec52 .heading-sub-title + .heading-title {                margin-top: 30px;            }        .gf-heading-60f8df4f7f4d0 .heading-title {            color: #333333 !important;            font-size: 24px !important;            line-height: 1.42em !important;        }        @media (min-width: 992px) and (max-width: 1199px) {            .gf-heading-60f8df4f7f4d0 .heading-title {                font-size: 24px !important;            }        }        @media (min-width: 768px) and (max-width: 991px) {            .gf-heading-60f8df4f7f4d0 .heading-title {                font-size: 24px !important;            }        }        @media (min-width: 576px) and (max-width: 767px) {            .gf-heading-60f8df4f7f4d0 .heading-title {                font-size: 24px !important;            }        }        @media (max-width: 575px) {            .gf-heading-60f8df4f7f4d0 .heading-title {                font-size: 24px !important;            }        }            .gf-heading-60f8df4f7f4d0 .heading-sub-title + .heading-title {                margin-bottom: 17px;            }        .gf-heading-60f8df4f7f4d0 .heading-sub-title {            font-size: 15px !important;            line-height: 15px !important;            letter-spacing: 0px !important;        }        @media (min-width: 992px) and (max-width: 1199px) {            .gf-heading-60f8df4f7f4d0 .heading-sub-title {                font-size: 15px !important;                line-height: 15px !important;            }        }        @media (min-width: 768px) and (max-width: 991px) {            .gf-heading-60f8df4f7f4d0 .heading-sub-title {                font-size: 15px !important;                line-height: 15px !important;            }        }        @media (min-width: 576px) and (max-width: 767px) {            .gf-heading-60f8df4f7f4d0 .heading-sub-title {                font-size: 15px !important;                line-height: 15px !important;            }        }        @media (max-width: 575px) {            .gf-heading-60f8df4f7f4d0 .heading-sub-title {                font-size: 15px !important;                line-height: 15px !important;            }        }    .gf-heading-60f8df4f7f4d0 .heading-sub-title {        font-family: Libre Baskerville !important;        font-weight: 400 !important;        font-style: italic !important;    }");</script></body>
</html> <!-- end of site. what a ride! -->

